package gifty_test.search.MODEL.copy;

public class cadeau {
private int idcadeaux;
private String nom_cadeaux;
private String hobbies;
private int prix;
private String type_personne;
private byte[] image;

public int getId_cadeau() {
	return idcadeaux;
}
public  void setId_cadeau(int idcadeaux) {
	this.idcadeaux = idcadeaux;
}
public String getNom_cadeaux() {
	return nom_cadeaux;
}
public void setNom_cadeaux(String nom_cadeaux) {
	this.nom_cadeaux = nom_cadeaux;
}
public String getHobbies() {
	return hobbies;
}
public void setHobbies(String hobbies) {
	this.hobbies = hobbies;
}
public int getPrix() {
	return prix;
}
public void setPrix(int prix) {
	this.prix = prix;
}
public String getType_personne() {
	return type_personne;
}
public void setType_personne(String type_personne) {
	this.type_personne = type_personne;
}
public byte[] getImage() {
	return image;
}
public void setImage(byte[] barry) {
	this.image=barry;
}

}
