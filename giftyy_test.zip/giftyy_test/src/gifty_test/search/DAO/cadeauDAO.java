package gifty_test.search.DAO;


import java.beans.Transient;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;



import gifty_test.search.MODEL.copy.cadeau;

public class cadeauDAO {
	//private Connection connection;
	

	    public List<cadeau>searchcadeau() {
	    	List<cadeau> Cadeau = new ArrayList<cadeau>();
	    	try {
			       Class.forName("com.mysql.cj.jdbc.Driver");
			      
			       }catch(ClassNotFoundException e)
			        {
			    	   System.out.print("errr");
			    	   
			        }
		    	
	    	String utilisateur = "root";
	       
	    	Connection connexion=null;
	    	Statement statement = null;
	    	ResultSet resultat = null; 
	    	//loadDataBase();

	        try {
	        	
	        	
	        	connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/gifty",utilisateur,"SALMA");
	        	
	        	 statement = connexion.createStatement();
	        	 
	        	 //execution requete
	        	 resultat = statement.executeQuery("SELECT  nom_cadeaux , prix FROM cadeaux where idcadeaux=4 ;");
	        	
	        		
                //recuperation donnee
	        	while (resultat.next()) {
	        		String nom_cadeaux = resultat.getString("nom_cadeaux");
	        		int prix = resultat.getInt("prix");
	        		
	        		
	        		cadeau cad = new cadeau();
	        		cad.setNom_cadeaux(nom_cadeaux);
	        		cad.setPrix(prix);
	        		
	        		Cadeau.add(cad);
	        		
	        	}

	          
	        } catch (SQLException e) {}
	        finally {
	        	
	        	try {
	        		if (resultat !=null)
	        			resultat.close();
	        		if (statement !=null)
	        			statement.close();
	        		if (connexion !=null)
	        			connexion.close();
	        		
	        		
	        	}catch(SQLException ignore)
	        	{}
	        }
	        return Cadeau;
	    }
}